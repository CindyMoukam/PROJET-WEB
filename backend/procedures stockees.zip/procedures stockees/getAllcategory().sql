CREATE PROCEDURE getAllcategory()
BEGIN
    -- Sélectionner toutes les catégories de la table des catégories
    SELECT * FROM category;
END
